package bg.DNDWarehouse.warehouseApp.controllers;

import bg.DNDWarehouse.warehouseApp.entities.Packet;
import bg.DNDWarehouse.warehouseApp.repositories.PacketRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/packet")
public class PacketController {

    private PacketRepository packetRepo;
    PacketController(PacketRepository packetRepository)
    {
        packetRepo = packetRepository;
    }

    @GetMapping("/fetch")
    private List<Packet> getAllPackets()
    {
        return packetRepo.findAll();
    }
}
