package bg.DNDWarehouse.warehouseApp.controllers;

import bg.DNDWarehouse.warehouseApp.entities.City;
import bg.DNDWarehouse.warehouseApp.entities.Employee;
import bg.DNDWarehouse.warehouseApp.repositories.CityRepository;
import bg.DNDWarehouse.warehouseApp.repositories.EmployeeRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/Employee")
public class EmployeeController {

    private final EmployeeRepository employeeRepo;
    private final CityRepository cityRepo;

    EmployeeController(EmployeeRepository employeeRepository, CityRepository cityRepository)
    {
        employeeRepo = employeeRepository;
        cityRepo = cityRepository;
    }

    @GetMapping("/fetch")
    private List<Employee> getAllEmployees()
    {
        return employeeRepo.findAll();
    }
    @GetMapping("/fetch/email")
    private Employee employeeByEmail(String email)
    {
        return employeeRepo.fetchEmployeeWithEmail(email);
    }

    @GetMapping("/find/name")
    public ResponseEntity<?> findEmployeeByFullName(String fname, String lname)
    {
        List<Employee> result = employeeRepo.findEmployeeByFirstNameAndLastName(fname, lname);
        return ResponseEntity.ok(result.isEmpty()? result : "Not Found!");
    }

    @GetMapping("/filter")
    public ResponseEntity<?> filterEmployees(String fname, String lname, int currentPage, int perPage)
    {
        Pageable pageable = PageRequest.of(currentPage - 1, perPage);
        Page<Employee> employees = employeeRepo.filterEmployees(pageable, fname.toLowerCase(), lname.toLowerCase());
        Map<String, Object> response = new HashMap<>();
        response.put("totalElements", employees.getTotalElements());
        response.put("totalPages", employees.getTotalPages());
        response.put("employees", employees.getContent());
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/delete")
    public String deleteEmployee(String fname, String lname)
    {
        List<Employee> result = employeeRepo.findEmployeeByFirstNameAndLastName(fname, lname);
        if (result.isEmpty())
        {
            // return ResponseEntity.ok("Client not found!")
            // return ResponseEntity.noContent().build()
            return "Client not found!";
        }
        for(Employee employee: result)
        {
            employeeRepo.delete(employee);
        }
        // return ResponseEntity.ok(fname + " " + lname + "was deleted!")
        return fname + " " + lname + " was deleted!";
    }

    @PostMapping("/save")
    public List<Employee> persistEmployee(String fname, String lname, String email)
    {
        List<Employee> employees = employeeRepo.findEmployeeByFirstNameAndLastName(fname, lname);
        List<Employee> response = new ArrayList<>();

        if(employees.isEmpty())
        {
            response.add(employeeRepo.save(new Employee(fname, lname, email)));
        }
        for(Employee employee: employees) {
            employee.setEmail(email);
            response.add(employeeRepo.save(employee));
        }
        return response;
    }

    @GetMapping("/cities")
    private List<City> getAllCities()
    {
        return cityRepo.findAll();
    }
}
