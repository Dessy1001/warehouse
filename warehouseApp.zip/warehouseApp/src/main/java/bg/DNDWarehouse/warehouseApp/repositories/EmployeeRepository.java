package bg.DNDWarehouse.warehouseApp.repositories;

import bg.DNDWarehouse.warehouseApp.entities.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee fetchEmployeeWithEmail(String email);

    List<Employee> findEmployeeByFirstNameAndLastName(String firstName, String lastName);
    @Query("SELECT e " +
            "FROM Employee e " +
            "WHERE " +
            "lower(e.firstName) " +
            "LIKE :#{#firstName == null || #firstName.isEmpty()? '%' : #firstName+'%'} " +
            "AND lower(e.lastName) " +
            "LIKE :#{#lastName == null || #lastName.isEmpty()? '%' : #lastName+'%'}")
    Page<Employee> filterEmployees(Pageable pageable, String firstName, String lastName);

}
