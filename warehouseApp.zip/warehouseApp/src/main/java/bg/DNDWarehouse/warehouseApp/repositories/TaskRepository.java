package bg.DNDWarehouse.warehouseApp.repositories;

import bg.DNDWarehouse.warehouseApp.entities.Employee;
import bg.DNDWarehouse.warehouseApp.entities.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface TaskRepository extends JpaRepository<Task, Long> {

    Optional<Task> findTaskById(Long id);

    @Query("SELECT t_e " +
            "FROM Task t " +
            "JOIN t.employees t_e " +
            "WHERE t.id = :taskId")
    List<Employee> getTaskEmployees(Long taskId);

//    @Query("SELECT t.id AS taskNumber, t_e.firstName, t_e.lastName " +
//            "FROM Task t " +
//            "JOIN t.employees t_e " +
//            "WHERE t_e.firstName = :fname AND t_e.lastName = :lname"
//    )
//    List<Employee> getTaskEmployee(String fname, String lname);
}
