package bg.DNDWarehouse.warehouseApp.entities;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
public class Task {
    @Id
    @GeneratedValue(strategy =GenerationType.IDENTITY)
    private Long id;
    private String description;
    private Boolean ongoing;
    private Date start;
    private Date finish;

    @ManyToMany
    @JoinTable(
            name = "task_employee",
            joinColumns = @JoinColumn(name = "task_id"),
            inverseJoinColumns = @JoinColumn(name = "employee_id")
    )
    private Set<Employee> employees;

    public Task(String description, Boolean ongoing, Date start) {
        this.description = description;
        this.start = start;
        this.ongoing = ongoing;
    }

    public Task(){};

    public Long getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getFinish() {
        return finish;
    }

    public void setFinish(Date finish) {
        this.finish = finish;
    }

    public Boolean getOngoing() {
        return ongoing;
    }

    public void setOngoing(Boolean ongoing) {
        this.ongoing = ongoing;
    }

    public Set<Employee> getEmployees() {
        return employees;
    }

    public void hireEmployee(Employee employee) {

        employees.add(employee);
    }

    public void fireEmployee(Employee employee) {

        employees.remove(employee);
    }
}
