package bg.DNDWarehouse.warehouseApp.controllers;

import bg.DNDWarehouse.warehouseApp.entities.Employee;
import bg.DNDWarehouse.warehouseApp.entities.Task;
import bg.DNDWarehouse.warehouseApp.repositories.EmployeeRepository;
import bg.DNDWarehouse.warehouseApp.repositories.TaskRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequestMapping("/task")
public class TaskController {

    private TaskRepository taskRepo;
    private EmployeeRepository employeeRepo;
    TaskController(TaskRepository taskRepository, EmployeeRepository employeeRepository) {
        taskRepo = taskRepository;
        employeeRepo = employeeRepository;
    }

    @PostMapping("/hireEmployee")
    public ResponseEntity<?> hireEmployee(Long taskNumber, String fname, String lname) {
        List<Employee> employees = employeeRepo.findEmployeeByFirstNameAndLastName(fname, lname);
        if(employees.isEmpty())
            return ResponseEntity.ok("There is no employee with such name.");

        for(Employee employee: employees)
        {
            Optional<Task> task1 = taskRepo.findTaskById(taskNumber);
            if(task1.isPresent())
            {
                task1.get().hireEmployee(employee);
                taskRepo.save(task1.get());
                return ResponseEntity.ok(fname + lname + " has been hired for task " + taskNumber + ".");
            }
            else
            {
                return ResponseEntity.ok("Invalid task number");
            }
        }
        return ResponseEntity.ok(null);
    }
    @PostMapping("/fireEmployee")
    public ResponseEntity<?> fireEmployee(Long taskNumber, String fname, String lname) {
        Optional<Task> task1 = taskRepo.findTaskById(taskNumber);
        if(task1.isPresent())
        {
            List<Employee> task_employees = taskRepo.getTaskEmployees(taskNumber);
                if(task_employees.isEmpty())
                    return ResponseEntity.ok("There is no such employee working on this task.");
                if(employeeRepo.findEmployeeByFirstNameAndLastName(fname, lname).isEmpty())
                    return ResponseEntity.ok("Invalid employee name.");
            Employee questionableEmployee = employeeRepo.findEmployeeByFirstNameAndLastName(fname, lname).get(0);
            if(task_employees.contains(questionableEmployee))
            {
                task1.get().fireEmployee(questionableEmployee);
                taskRepo.save(task1.get());
            }
            return ResponseEntity.ok(fname + lname + " has been fired from task " + taskNumber + ".");
        }
        else
        {
            return ResponseEntity.ok("Invalid task number");
        }
    }

    @PostMapping("/createTask")
    public ResponseEntity<?> createTask(String description, Boolean ongoing, Date timestamp)
    {
        Task task1 = taskRepo.save(new Task (description, ongoing, timestamp));
        return ResponseEntity.ok("Task number " + task1.getId() + " was saved.");
    }
}
